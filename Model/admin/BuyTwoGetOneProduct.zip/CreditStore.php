<?php

namespace App\Model\admin;

use Illuminate\Database\Eloquent\Model;

class CreditStore extends Model
{
    protected $table = 'tbl_store_credit';
    protected $guarded = ['id'];
}
