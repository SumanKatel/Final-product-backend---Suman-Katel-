<?php

namespace App\Model\admin;

use Illuminate\Database\Eloquent\Model;

class Voucher extends Model {
    
    protected $table = 'voucher';
    protected $guarded = ['id'];
}
