<?php

namespace App\Model\admin;

use Illuminate\Database\Eloquent\Model;

class OtherService extends Model
{
    protected $table = 'tbl_other_service';
    protected $guarded = ['id'];
}
