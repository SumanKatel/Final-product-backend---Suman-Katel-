<?php

namespace App\Model\admin;

use Illuminate\Database\Eloquent\Model;

class CustomerSupportReply extends Model {
	
    protected $table = 'tbl_customer_support_reply';
    protected $guarded = ['id'];    
}
