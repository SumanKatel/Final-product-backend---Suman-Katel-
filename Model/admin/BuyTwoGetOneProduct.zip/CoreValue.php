<?php

namespace App\Model\admin;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class CoreValue extends Model {

    protected $table = 'tbl_core_value';
    protected $guarded = ['id'];

}
