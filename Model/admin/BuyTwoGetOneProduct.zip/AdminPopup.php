<?php

namespace App\Model\admin;

use Illuminate\Database\Eloquent\Model;

class AdminPopup extends Model {

    protected $table = 'tbl_popup';
    protected $guarded = ['id'];
}
