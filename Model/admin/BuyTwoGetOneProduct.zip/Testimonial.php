<?php

namespace App\Model\admin;

use Illuminate\Database\Eloquent\Model;

class Testimonial extends Model
{
    protected $table='tbl_testimonial';
    protected $guarded=['id'];
}
