<?php

namespace App\Model\admin;

use Illuminate\Database\Eloquent\Model;

class TrainingParticipant extends Model
{
    protected $table='tbl_training_participant';
    protected $guarded=['id'];
}
