<?php

namespace App\Model\admin;

use Illuminate\Database\Eloquent\Model;

class SubProduct extends Model
{
    protected $table='tbl_sub_product';
    protected $guarded=['id'];
}
