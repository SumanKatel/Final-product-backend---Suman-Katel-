<?php

namespace App\Model\admin;

use Illuminate\Database\Eloquent\Model;

class RelationPostCategory extends Model {
    
    protected $table = 'rel_post_category';
    protected $guarded = ['id'];    
}
