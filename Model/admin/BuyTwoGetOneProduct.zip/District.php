<?php

namespace App\Model\admin;

use Illuminate\Database\Eloquent\Model;

class District extends Model {
	
    protected $table = 'tbl_district';
    protected $guarded = ['id'];    
}
