<?php

namespace App\Model\admin;

use Illuminate\Database\Eloquent\Model;

class CustomerSupport extends Model {
	
    protected $table = 'tbl_customer_support';
    protected $guarded = ['id'];    
}
