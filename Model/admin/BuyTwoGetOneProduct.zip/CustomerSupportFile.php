<?php

namespace App\Model\admin;

use Illuminate\Database\Eloquent\Model;

class CustomerSupportFile extends Model {
	
    protected $table = 'tbl_customer_support_file';
    protected $guarded = ['id'];    
}
