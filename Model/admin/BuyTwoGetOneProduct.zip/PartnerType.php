<?php

namespace App\Model\admin;

use Illuminate\Database\Eloquent\Model;

class PartnerType extends Model {

    protected $table = 'tbl_partner_type';
    protected $guarded = ['id'];
}
