<?php

namespace App\Model\admin;

use Illuminate\Database\Eloquent\Model;

class BloodGroup extends Model {
    
    protected $table = 'tbl_blood_group';
    protected $guarded = ['id'];    
}
