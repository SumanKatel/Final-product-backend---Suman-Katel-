<?php

namespace App\Model\admin;

use Illuminate\Database\Eloquent\Model;

class CustomerSupportReplyFile extends Model {
	
    protected $table = 'tbl_customer_support_reply_file';
    protected $guarded = ['id'];    
}
