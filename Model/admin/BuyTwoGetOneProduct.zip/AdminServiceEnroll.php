<?php

namespace App\Model\admin;

use Illuminate\Database\Eloquent\Model;

class AdminServiceEnroll extends Model
{
    protected $table = 'tbl_service_enroll';
    protected $guarded = ['id'];
}
