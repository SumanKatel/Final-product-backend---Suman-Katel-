<?php

namespace App\Model\admin;

use Illuminate\Database\Eloquent\Model;

class AdminWhyUs extends Model
{
    protected $table = 'tbl_why_us';
    protected $guarded = ['id'];
}
