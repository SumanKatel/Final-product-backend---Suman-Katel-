<?php

namespace App\Model\admin;

use Illuminate\Database\Eloquent\Model;

class Medium extends Model {
	
    protected $table = 'tbl_medium';
    protected $guarded = ['id'];    
}
